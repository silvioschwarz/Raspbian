<?php
// .x..... = Hauptseite
// 1.x..... = Installation
// 0x..... = Dateien
// 1x..... = Serverseitig
// 2x..... = Benutzerseitig

$error_code = array();
$error_code['0x0001'] = 'Fehler beim Laden der Seite. Fehlercode: 0x0001'; // index.php
$error_code['0x0002'] = 'Fehler beim Laden der Seite. Fehlercode: 0x0002'; // index.php
$error_code['0x0003'] = 'Fehler beim Laden der Seite. Fehlercode: 0x0003'; // index.php
$error_code['0x0004'] = 'Fehler beim Laden der Seite. Fehlercode: 0x0004'; // index.php
$error_code['0x0005'] = 'Fehler beim Laden der Seite. Fehlercode: 0x0005'; // index.php
$error_code['0x0006'] = 'Fehler beim Laden der Seite. Fehlercode: 0x0006'; // index.php
$error_code['0x0007'] = 'Fehler beim Laden der Seite. Fehlercode: 0x0007'; // index.php
$error_code['0x0008'] = 'Fehler beim Laden der Seite. Fehlercode: 0x0008'; // index.php
$error_code['0x0009'] = 'Fehler beim Laden der Seite. Fehlercode: 0x0009'; // index.php
$error_code['0x0010'] = 'Fehler beim Laden der Seite. Fehlercode: 0x0010'; // index.php
$error_code['0x0011'] = 'Konnte Wert nicht in Konfigurationsdatei speichern! Fehlercode: 0x0011-';
$error_code['1x0001'] = 'Konnte Plugin nicht deaktivieren! Fehlercode: 1x0001'; // 
$error_code['1x0002'] = 'Konnte Plugin nicht aktivieren! Fehlercode: 1x0002'; // 

//$error_code['1x0001'] = 'Der Zugang steht nur im lokalem Netzwerk (LAN) zur Verfügung! Fehlercode: 1x0001'; // index.php

//$error_code['2x0001'] = 'Bitte gib einen gültigen Wert ein! Fehlercode: 2x0001'; // content/settings/overview.php

// Installation - install/..
//$error_code['10x0001'] = 'Fehler beim Laden der Seite. Fehlercode: 10x0001'; // index.php
?>